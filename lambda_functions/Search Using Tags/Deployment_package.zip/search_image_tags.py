import json
import psycopg2
import boto3


def lambda_handler(event, context):
    tag1 = event['queryStringParameters']['tag']
    tag2 = event['queryStringParameters']['tag2']
    s3_client = boto3.client('s3')
    connection = psycopg2.connect(
        host="my-db-instance.cy9ecey6190a.us-east-1.rds.amazonaws.com",
        database="initial_db",
        user="postgres",
        password="database123"
    )
    cursor = connection.cursor()

    cursor.execute("SELECT url, objects FROM images")
    data = cursor.fetchall()
    dict1 = {url: json.loads(tags) for url, tags in data}

    lst = [url for url, tags in dict1.items() if tag1 in tags and (len(tag2) == 0 or tag2 in tags)]

    signed_url_list = []
    for i in lst:
        element = i.split("/")
        image = element[-1]
        url = s3_client.generate_presigned_url(ClientMethod='get_object',
                                               Params={'Bucket': 'direct-upload-sid', 'Key': image}, ExpiresIn=600)
        signed_url_list.append(url)

    return {
        'statusCode': 200,
        'body': json.dumps(signed_url_list),
        'headers': {
            "Content-Type": "application/json",
            "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
            "Access-Control-Allow-Methods": "OPTIONS,POST,PUT,DELETE",
            "Access-Control-Allow-Origin": "*",
            "X-Requested-With": "*"
        }
    }
